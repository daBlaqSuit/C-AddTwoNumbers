﻿using System;

namespace AddNumbers
{
	class MainClass
	{
		public static void Main (string[] args)
		{
			/* This program will Add two Numbers from user input and prints the results,
			 * x = first input and y = second input from the user */

			//Take User's first input
			Console.WriteLine("Please enter your first number to calculate:");
			int x = Convert.ToInt32(Console.ReadLine ());

			//Take User's second input
			Console.WriteLine("Please enter your second number to calculate:");
			int y = Convert.ToInt32(Console.ReadLine ());
			//Add x + y and save it to results
			int results = x + y;

			//Print the results
			Console.WriteLine ("Your Calculated Result is {0}",results);
		}
	}
}
